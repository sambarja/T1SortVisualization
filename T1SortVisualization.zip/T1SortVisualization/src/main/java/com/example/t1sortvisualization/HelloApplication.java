/*
T1
EQ8
LBCPA2
MODULE 7
 */


package com.example.t1sortvisualization;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    private int[] data1;
    private int[] data2;

    @Override
    public void start(Stage stage) throws IOException {
        data1 = new int[]{10, 5, 7, 2, 18, 13, 6, 8, 17,1}; // Initialize the data array
        data2 = new int[]{10, 5, 7, 2, 18, 13, 6, 8, 17,1}; // Initialize the data array

        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));

        // Create an instance of the controller manually
        HelloController helloController = new HelloController();

        // Set the controller in the FXMLLoader
        fxmlLoader.setController(helloController);

        Pane root = fxmlLoader.load();

        // Initialize the controller with the root and data
        helloController.init(root, data1,data2);

        Scene scene = new Scene(root, 1000, 420);
        stage.setTitle("Sort Visualization");
        stage.setScene(scene);
        stage.show();

    }

    public static void main(String[] args) {
        launch();
    }
}
