package com.example.t1sortvisualization;

import javafx.animation.FillTransition;
import javafx.animation.KeyFrame;
import javafx.animation.ParallelTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.PauseTransition;
import javafx.beans.property.ObjectProperty;
import javafx.scene.layout.Pane;
import javafx.util.Duration;
import javafx.scene.shape.Rectangle;
import javafx.scene.paint.Color;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;


import java.util.Arrays;

public class HelloController {


    private static final int RECTANGLE_WIDTH = 35;
    private static final int RECTANGLE_HEIGHT_MULTIPLIER = 15;
    private static final int ANIMATION_SPEED = 500;

    private int[] data;
    private int[] data1;
    private Pane root;

    public void init(Pane root, int[] data, int[] data1) {
        this.root = root;
        this.data = data;
        this.data1 = data1;
        drawArrays(data);
    }

    public void startSorting(){
        selectionSortAnimation();
        bubbleSortAnimation();
    }

    public void selectionSortAnimation() {
        SequentialTransition animation = new SequentialTransition();

        for (int i = 0; i < data.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < data.length; j++) {
                if (data[j] < data[minIndex]) {
                    minIndex = j;
                }
            }
            animation.getChildren().add(createSwapTransition("s" + (i+1), "s" + (minIndex+1)));
            swap(i, minIndex,data);
        }
        animation.play();

    }


    public void bubbleSortAnimation() {
        SequentialTransition animation = new SequentialTransition();


        for (int i = 0; i < data1.length - 1; i++) {
            for (int j = 0; j < data1.length - 1 - i; j++) {
                if (data1[j] > data1[j + 1]) {
                    animation.getChildren().add(createSwapTransition("b" + (j + 1), "b" + (j + 2)));
                    swap(j, j + 1,data1);
                }
            }
        }
        animation.play();
    }


    private void swap(int i, int j,int[] data) {
        int temp = data[i];
        data[i] = data[j];
        data[j] = temp;
    }

    private ParallelTransition createSwapTransition(String index1, String index2) {

        Rectangle rect1 = (Rectangle) root.lookup("#" + index1);
        Rectangle rect2 = (Rectangle) root.lookup("#" + index2);

        // Set initial color explicitly to unsorted color
        rect1.setFill(Color.GREEN);
        rect2.setFill(Color.GREEN);

        double initialX1 = rect1.getLayoutX();
        double initialX2 = rect2.getLayoutX();


        KeyValue kv1 = new KeyValue(rect1.layoutXProperty(), initialX2);
        KeyValue kv2 = new KeyValue(rect2.layoutXProperty(), initialX1);

        KeyFrame kf1 = new KeyFrame(Duration.millis(ANIMATION_SPEED), kv1);
        KeyFrame kf2 = new KeyFrame(Duration.millis(ANIMATION_SPEED), kv2);

        Timeline timeline1 = new Timeline(kf1, kf2);


        System.out.println("final rect 1 x: " + rect1.getLayoutX());
        System.out.println("final rect 2 x: " + rect2.getLayoutX());



        FillTransition colorChange1 = new FillTransition(Duration.millis(ANIMATION_SPEED), rect1);
        colorChange1.setToValue(Color.RED);

        FillTransition colorChange2 = new FillTransition(Duration.millis(ANIMATION_SPEED), rect2);
        colorChange2.setToValue(Color.RED);



        ParallelTransition swap = new ParallelTransition(timeline1,colorChange1, colorChange2);

        rect1.setLayoutX(initialX2);
        rect2.setLayoutX(initialX1);


        String tempID = rect1.getId();
        rect1.setId(rect2.getId());
        rect2.setId(tempID);



        swap.setOnFinished(event -> {
            rect1.setFill(Color.BLUE);
            rect2.setFill(Color.BLUE);

        });

        return swap;

    }


    private void drawArrays(int[]data) {
        int maxHeight = Arrays.stream(data).max().orElse(0) * RECTANGLE_HEIGHT_MULTIPLIER;

        for (int i = 0; i < data.length; i++) {
            drawArray("#b" + (i + 1), data[i], maxHeight);
            drawArray("#s" + (i + 1), data[i], maxHeight);
        }


    }

    private void drawArray(String rectangleId, int value, int maxHeight) {
        Rectangle rectangle = (Rectangle) root.lookup(rectangleId);
        if (rectangle != null) {
            rectangle.setHeight(value * RECTANGLE_HEIGHT_MULTIPLIER);
            rectangle.setY(maxHeight - value * RECTANGLE_HEIGHT_MULTIPLIER-100);
        }
        // Change the initial color to a color indicating unsorted state (e.g., Color.GREEN)
        rectangle.setFill(Color.GREEN);
    }
}
