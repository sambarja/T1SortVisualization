module com.example.t1sortvisualization {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.t1sortvisualization to javafx.fxml;
    exports com.example.t1sortvisualization;
}